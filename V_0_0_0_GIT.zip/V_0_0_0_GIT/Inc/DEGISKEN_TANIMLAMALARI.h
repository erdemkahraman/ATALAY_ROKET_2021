// H Dosyasi: DEGISKEN_TANIMLAMALARI.h
// Dosya Adi: 17_01_2021_ROKET_GOMULU_YAZILIM
// Yazan: BEYTULLAH CICEKCI
// Tarih: 17_01_2021
// Saat: 17:30
// Aciklama:

#include <stdint.h>

typedef uint8_t  UINT8;
typedef uint16_t UINT16;
typedef uint32_t UINT32;

typedef int			 INT;
typedef int8_t	 INT8;
typedef int16_t	 INT16;
typedef int32_t  INT32;

typedef float 	 FLOAT;

