// H Dosyasi: Global_variable.h
// Dosya Adi: 17_01_2021_ROKET_GOMULU_YAZILIM_V_0_0_0
// Yazan: Beytullah_Cicekci	
// Tarih: 17_01_2021
// Saat: 18:18
// Aciklama:

#include "DEGISKEN_TANIMLAMALARI.h"


typedef union
{
	struct
	{
		UINT8 kalan  : 1 ;
		UINT8 HZ_1	 : 1 ;    //  1 saniyelik task      //
		UINT8 HZ_2   : 1 ;    // 500 milisaniyelik task //      
		UINT8 HZ_10	 : 1 ;    // 100 milisaniyelik task //
		UINT8 HZ_20  : 1 ;	  //  50 milisaniyelik task //		
		UINT8 HZ_40  : 1 ;	  //  25 milisaniyelik task //		
		UINT8 HZ_100 : 1 ;	  //  10 milisaniyelik task //
		UINT8 KHZ_1  : 1 ;    //  1 milisaniyelik task  //
	
	}Hz_t;
	
	 UINT8 u8;

}Tasklar_t;

typedef struct
{

UINT16 Sistem_saati;

Tasklar_t tasklar_t;	

	
	

}GL_t;

extern GL_t Gl;

