// C Dosyasi: Atalay_Roket_main.c
// Dosya Adi: 17_01_2021_ROKET_GOMULU_YAZILIM
// Yazan: BEYTULLAH CICEKCI
// Tarih: 17_01_2021
// Saat: 17:42
// Aciklama:

#include "Atalay_Roket_main.h"

extern TIM_HandleTypeDef htim1;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
        // Device header
	if(htim->Instance == htim1.Instance)
	{
		Gl.Sistem_saati++;			// 1 KHZ'LIK = 1 ms TIMER KESMESI 
	
		if( (Gl.Sistem_saati % 1000) == 1 )
		{
		
		Gl.tasklar_t.Hz_t.HZ_1 = 1 ;
		
		}
		
		if( (Gl.Sistem_saati % 500) == 1 )
		{
		
		Gl.tasklar_t.Hz_t.HZ_2 = 1 ;
		
		}
		
				if( (Gl.Sistem_saati % 100) == 1 )
		{
		
		Gl.tasklar_t.Hz_t.HZ_10 = 1 ;
		
		}
		
		if( (Gl.Sistem_saati % 50) == 1 )
		{
		
		Gl.tasklar_t.Hz_t.HZ_20 = 1 ;
		
		}
		
		if( (Gl.Sistem_saati % 25) == 1 )
		{
		
		Gl.tasklar_t.Hz_t.HZ_40 = 1 ;
		
		}
		
		if( (Gl.Sistem_saati % 10) == 1 )
		{
		
		Gl.tasklar_t.Hz_t.HZ_100 = 1 ;
		
		}
				
	}
}

INT atalay_roket_2021_main(void)
{



	while(1)
	{

if(Gl.tasklar_t.Hz_t.HZ_1 == 1)
{
HAL_GPIO_TogglePin(GPIOA,GPIO_PIN_1);
Gl.tasklar_t.Hz_t.HZ_1 = 0;
}
		
		
	}



}
	












