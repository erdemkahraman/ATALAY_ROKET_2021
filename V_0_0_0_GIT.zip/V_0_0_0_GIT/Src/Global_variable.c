// C Dosyasi: Global_variable.c
// Dosya Adi: 17_01_2021_ROKET_GOMULU_YAZILIM_V_0_0_0
// Yazan: Beytullah_Cicekci	
// Tarih: 17_01_2021
// Saat: 18:18
// Aciklama:

#include "Global_variable.h"

GL_t Gl = {0};

